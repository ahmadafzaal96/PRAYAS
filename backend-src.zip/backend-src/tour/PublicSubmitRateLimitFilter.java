package com.prayas.platform.tour;

import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * 5 submissions per hour per IP on the public tour-request endpoint. A
 * simple in-memory bucket is enough for a single-instance deployment; move
 * to a Redis-backed Bucket4j proxy manager if this ever runs on more than
 * one node.
 */
public class PublicSubmitRateLimitFilter extends OncePerRequestFilter {

    private static final String PROTECTED_PATH = "/api/v1/public/tour-requests";
    private final ConcurrentMap<String, Bucket> buckets = new ConcurrentHashMap<>();

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                     FilterChain chain) throws ServletException, IOException {
        boolean isProtectedPost = "POST".equalsIgnoreCase(request.getMethod())
                && PROTECTED_PATH.equals(request.getRequestURI());

        if (isProtectedPost) {
            Bucket bucket = buckets.computeIfAbsent(clientIp(request), ip ->
                    Bucket.builder()
                            .addLimit(Bandwidth.simple(5, Duration.ofHours(1)))
                            .build());
            if (!bucket.tryConsume(1)) {
                response.setStatus(429);
                response.getWriter().write("{\"error\":\"Too many requests, try again later.\"}");
                return;
            }
        }
        chain.doFilter(request, response);
    }

    private String clientIp(HttpServletRequest request) {
        String forwarded = request.getHeader("X-Forwarded-For");
        return forwarded != null ? forwarded.split(",")[0].trim() : request.getRemoteAddr();
    }
}
