package com.prayas.platform.tour;

public enum ProgrammeType {
    CAMPUS_TOUR
    // Future: RURAL_VISIT, WORKSHOP, ... reuse the same requirement/workflow engine.
}
