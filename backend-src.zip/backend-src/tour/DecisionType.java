package com.prayas.platform.tour;

public enum DecisionType {
    APPROVE,
    REJECT,
    PROPOSE_DATE
}
