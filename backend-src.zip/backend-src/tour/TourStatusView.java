package com.prayas.platform.tour;

import java.time.LocalDate;
import java.time.LocalTime;

public record TourStatusView(
        ProgrammeStatus status,
        LocalDate visitDate,
        LocalDate proposedDate, // set only when status == RESCHEDULE_PROPOSED
        LocalTime arrivalTime,
        LocalTime departureTime,
        int currentStudentCount
) {
    public static TourStatusView from(Programme programme, int currentStudentCount) {
        return new TourStatusView(
                programme.getStatus(),
                programme.getVisitDate(),
                programme.getProposedDate(),
                programme.getArrivalTime(),
                programme.getDepartureTime(),
                currentStudentCount
        );
    }
}
