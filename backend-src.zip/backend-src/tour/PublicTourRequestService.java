package com.prayas.platform.tour;

import com.prayas.platform.school.School;
import com.prayas.platform.school.SchoolRepository;
import com.prayas.platform.venue.Venue;
import com.prayas.platform.venue.VenueRepository;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;

@Service
public class PublicTourRequestService {

    private final ProgrammeRepository programmeRepository;
    private final CampusTourDetailsRepository tourDetailsRepository;
    private final HeadcountRevisionRepository headcountRepository;
    private final TourInterestRepository tourInterestRepository;
    private final SchoolRepository schoolRepository;
    private final VenueRepository venueRepository;
    private final TrackingTokenGenerator tokenGenerator;
    private final CaptchaVerifier captchaVerifier;
    private final TourProperties props;
    private final TourDecisionService decisionService;

    public PublicTourRequestService(ProgrammeRepository programmeRepository,
                                     CampusTourDetailsRepository tourDetailsRepository,
                                     HeadcountRevisionRepository headcountRepository,
                                     TourInterestRepository tourInterestRepository,
                                     SchoolRepository schoolRepository,
                                     VenueRepository venueRepository,
                                     TrackingTokenGenerator tokenGenerator,
                                     CaptchaVerifier captchaVerifier,
                                     TourProperties props,
                                     TourDecisionService decisionService) {
        this.programmeRepository = programmeRepository;
        this.tourDetailsRepository = tourDetailsRepository;
        this.headcountRepository = headcountRepository;
        this.tourInterestRepository = tourInterestRepository;
        this.schoolRepository = schoolRepository;
        this.venueRepository = venueRepository;
        this.tokenGenerator = tokenGenerator;
        this.captchaVerifier = captchaVerifier;
        this.props = props;
        this.decisionService = decisionService;
    }

    @Transactional
    public TourRequestCreated submit(TourRequestCreate request, String remoteIp) {
        // Honeypot: a real school never fills a field named "website" that's
        // hidden by CSS. Silently pretend success so bots don't learn to skip it.
        if (request.website() != null && !request.website().isBlank()) {
            return fakeSuccessForBots();
        }
        if (!captchaVerifier.verify(request.captchaToken(), remoteIp)) {
            throw new IllegalArgumentException("Captcha verification failed");
        }

        School school = new School(request.school().name());
        school.setAddress(request.school().address());
        school.setVillageOrTown(request.school().villageOrTown());
        school.setDistrict(request.school().district());
        school.setState(request.school().state());
        schoolRepository.save(school);

        Programme programme = new Programme(request.visitDate());
        programme.setArrivalTime(request.arrivalTime());
        programme.setDepartureTime(request.departureTime());
        programmeRepository.save(programme);

        TrackingTokenGenerator.TokenPair token = tokenGenerator.generate();
        CampusTourDetails details = new CampusTourDetails(
                programme, school, request.contact().name(), request.contact().phone(), token.hash());
        details.setContactEmail(request.contact().email());
        details.setLunchRequired(request.lunch().required());
        details.setInterestNotes(request.interestNotes());
        tourDetailsRepository.save(details);

        List<Venue> venues = venueRepository.findAllById(request.venueIds());
        for (Venue venue : venues) {
            tourInterestRepository.save(new TourInterest(programme, venue));
        }

        HeadcountRevision revision = new HeadcountRevision(
                programme, 1, request.studentCount(), request.teachers() == null ? 0 : request.teachers().size(), null);
        revision.setVegMeals(request.lunch().vegMeals());
        revision.setNonVegMeals(request.lunch().nonVegMeals());
        headcountRepository.save(revision);

        programme.transitionTo(ProgrammeStatus.UNDER_REVIEW);

        return new TourRequestCreated(programme.getId(), token.rawToken(), programme.getStatus());
    }

    @Transactional(readOnly = true)
    public TourStatusView status(String rawToken) {
        CampusTourDetails details = tourDetailsRepository
                .findByTrackingTokenHash(tokenGenerator.hash(rawToken))
                .orElseThrow(() -> new NoSuchElementException("No tour request for this link"));
        int currentCount = headcountRepository
                .findTopByProgrammeIdOrderByRevisionNoDesc(details.getProgramme().getId())
                .map(HeadcountRevision::getStudentCount)
                .orElse(0);
        return TourStatusView.from(details.getProgramme(), currentCount);
    }

    @Transactional
    public void reviseHeadcount(String rawToken, int newStudentCount, int newTeacherCount) {
        CampusTourDetails details = tourDetailsRepository
                .findByTrackingTokenHash(tokenGenerator.hash(rawToken))
                .orElseThrow(() -> new NoSuchElementException("No tour request for this link"));
        Programme programme = details.getProgramme();

        LocalDate freezeDate = programme.getVisitDate().minusDays(props.getHeadcountFreezeDays());
        if (!LocalDate.now().isBefore(freezeDate)) {
            throw new AccessDeniedException(
                    "Headcount is frozen from %s; contact Prayas directly to change it".formatted(freezeDate));
        }

        int nextRevisionNo = headcountRepository
                .findTopByProgrammeIdOrderByRevisionNoDesc(programme.getId())
                .map(r -> r.getRevisionNo() + 1)
                .orElse(1);
        headcountRepository.save(new HeadcountRevision(programme, nextRevisionNo, newStudentCount, newTeacherCount, null));

        if (programme.getStatus() == ProgrammeStatus.APPROVED) {
            decisionService.flagRequirementsForHeadcountChange(programme.getId());
        }
    }

    private TourRequestCreated fakeSuccessForBots() {
        return new TourRequestCreated(0L, tokenGenerator.generate().rawToken(), ProgrammeStatus.UNDER_REVIEW);
    }
}
