package com.prayas.platform.tour;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public record TourRequestCreate(
        @Valid @NotNull SchoolInfo school,
        @Valid @NotNull ContactInfo contact,
        @NotNull @Future LocalDate visitDate,
        LocalTime arrivalTime,
        LocalTime departureTime,
        @Size(max = 50) String gradeRange,
        @Min(1) @Max(500) int studentCount,
        @Valid @Size(max = 20) List<TeacherInfo> teachers,
        @NotEmpty List<Long> venueIds,
        @Size(max = 2000) String interestNotes,
        @Valid @NotNull LunchInfo lunch,
        @Size(max = 30) String vehicleNumber,
        @Size(max = 150) String arrivalPoint,
        @Size(max = 1000) String specialNeeds,
        @NotBlank String captchaToken,
        // Honeypot: must stay empty. A bot filling every field trips this.
        String website
) {
    public record SchoolInfo(
            @NotBlank @Size(max = 200) String name,
            @Size(max = 500) String address,
            @Size(max = 120) String villageOrTown,
            @Size(max = 120) String district,
            @Size(max = 80) String state
    ) {
    }

    public record ContactInfo(
            @NotBlank @Size(max = 150) String name,
            @NotBlank @Pattern(regexp = "^[0-9+ -]{7,20}$") String phone,
            @Email String email
    ) {
    }

    public record TeacherInfo(
            @NotBlank @Size(max = 150) String name,
            @Pattern(regexp = "^[0-9+ -]{7,20}$") String phone
    ) {
    }

    public record LunchInfo(
            boolean required,
            @Min(0) Integer vegMeals,
            @Min(0) Integer nonVegMeals
    ) {
    }
}
