package com.prayas.platform.tour;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;
import org.springframework.web.bind.annotation.*;

/**
 * Reachable with no login. Every write here goes through the honeypot,
 * captcha check, and per-IP rate limit before touching the database --
 * see PublicTourRequestService and PublicSubmitRateLimitFilter.
 */
@RestController
@RequestMapping("/api/v1/public")
public class PublicTourRequestController {

    private final PublicTourRequestService service;

    public PublicTourRequestController(PublicTourRequestService service) {
        this.service = service;
    }

    @PostMapping("/tour-requests")
    public TourRequestCreated submit(@Valid @RequestBody TourRequestCreate request,
                                      HttpServletRequest httpRequest) {
        return service.submit(request, httpRequest.getRemoteAddr());
    }

    @GetMapping("/tour-requests/{token}")
    public TourStatusView status(@PathVariable String token) {
        return service.status(token);
    }

    public record HeadcountUpdate(@Min(1) int studentCount, @Min(0) int teacherCount) {
    }

    @PostMapping("/tour-requests/{token}/headcount")
    public void reviseHeadcount(@PathVariable String token, @Valid @RequestBody HeadcountUpdate update) {
        service.reviseHeadcount(token, update.studentCount(), update.teacherCount());
    }
}
