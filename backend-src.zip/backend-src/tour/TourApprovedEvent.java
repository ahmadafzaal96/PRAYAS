package com.prayas.platform.tour;

public record TourApprovedEvent(Long programmeId) {
}
