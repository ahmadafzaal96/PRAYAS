package com.prayas.platform.tour;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * application.yml:
 *   prayas:
 *     tour:
 *       max-per-day: 3
 *       headcount-freeze-days: 1
 *       requirement-lead-days: 5
 */
@ConfigurationProperties(prefix = "prayas.tour")
public class TourProperties {

    /** Max approved tours allowed on a single visit date. Team-set value: 3. */
    private int maxPerDay = 3;

    /** Days before the visit date after which the school can no longer self-edit headcount. Team-set value: 1. */
    private int headcountFreezeDays = 1;

    /** Requirement due_date = visitDate - requirementLeadDays. */
    private int requirementLeadDays = 5;

    public int getMaxPerDay() {
        return maxPerDay;
    }

    public void setMaxPerDay(int maxPerDay) {
        this.maxPerDay = maxPerDay;
    }

    public int getHeadcountFreezeDays() {
        return headcountFreezeDays;
    }

    public void setHeadcountFreezeDays(int headcountFreezeDays) {
        this.headcountFreezeDays = headcountFreezeDays;
    }

    public int getRequirementLeadDays() {
        return requirementLeadDays;
    }

    public void setRequirementLeadDays(int requirementLeadDays) {
        this.requirementLeadDays = requirementLeadDays;
    }
}
