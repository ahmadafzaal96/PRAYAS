package com.prayas.platform.tour;

import com.prayas.platform.audit.AuditLog;
import com.prayas.platform.audit.AuditLogRepository;
import com.prayas.platform.domain.Domain;
import com.prayas.platform.domain.DomainRepository;
import com.prayas.platform.requirement.Requirement;
import com.prayas.platform.requirement.RequirementKind;
import com.prayas.platform.requirement.RequirementRepository;
import com.prayas.platform.user.AppUser;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;

/**
 * Owns the one transaction that matters in phase 1: deciding a tour request.
 * See phase1-design.md section 5 for the full walkthrough of why each step
 * is here (advisory lock, optimistic version, requirement spawning order).
 */
@Service
public class TourDecisionService {

    private static final String HOSPITALITY_LOGISTICS = "HOSPITALITY_LOGISTICS";
    private static final String VCU = "VCU";

    private final ProgrammeRepository programmeRepository;
    private final CampusTourDetailsRepository tourDetailsRepository;
    private final TourInterestRepository tourInterestRepository;
    private final RequirementRepository requirementRepository;
    private final DomainRepository domainRepository;
    private final AuditLogRepository auditLogRepository;
    private final AdvisoryLockDao advisoryLockDao;
    private final ApplicationEventPublisher events;
    private final TourProperties props;

    public TourDecisionService(ProgrammeRepository programmeRepository,
                                CampusTourDetailsRepository tourDetailsRepository,
                                TourInterestRepository tourInterestRepository,
                                RequirementRepository requirementRepository,
                                DomainRepository domainRepository,
                                AuditLogRepository auditLogRepository,
                                AdvisoryLockDao advisoryLockDao,
                                ApplicationEventPublisher events,
                                TourProperties props) {
        this.programmeRepository = programmeRepository;
        this.tourDetailsRepository = tourDetailsRepository;
        this.tourInterestRepository = tourInterestRepository;
        this.requirementRepository = requirementRepository;
        this.domainRepository = domainRepository;
        this.auditLogRepository = auditLogRepository;
        this.advisoryLockDao = advisoryLockDao;
        this.events = events;
        this.props = props;
    }

    @Transactional
    public Programme decide(Long programmeId, DecisionRequest request, AppUser actor) {
        Programme programme = programmeRepository.findById(programmeId)
                .orElseThrow(() -> new NoSuchElementException("Programme " + programmeId + " not found"));

        return switch (request.decision()) {
            case APPROVE -> approve(programme, request, actor);
            case REJECT -> reject(programme, request, actor);
            case PROPOSE_DATE -> proposeDate(programme, request, actor);
        };
    }

    private Programme approve(Programme programme, DecisionRequest request, AppUser actor) {
        // Step 1: serialize with any other decision on the same date before
        // we count how many tours are already approved for it.
        advisoryLockDao.lockDate(programme.getVisitDate());

        // Step 2: status transition (throws if not allowed; @Version guards
        // against a stale concurrent edit to this specific programme).
        programme.transitionTo(ProgrammeStatus.APPROVED);

        // Step 3: daily cap, now safe to check under the lock.
        long alreadyApproved = programmeRepository.countApprovedOnDate(programme.getVisitDate());
        if (alreadyApproved >= props.getMaxPerDay()) {
            throw new DailyCapExceededException(
                    "Daily cap of %d tours reached for %s".formatted(props.getMaxPerDay(), programme.getVisitDate()));
        }

        // Step 4: record the decision.
        programme.setDecidedBy(actor);
        programme.setDecidedAt(Instant.now());
        programme.setDecisionNote(request.note());

        // Step 5: spawn domain requirements (idempotent: unique on programme+kind).
        LocalDate dueDate = programme.getVisitDate().minusDays(props.getRequirementLeadDays());
        spawnRequirementsOnApproval(programme, dueDate);

        // Step 6: audit trail.
        auditLogRepository.save(AuditLog.byUser(actor.getId(), "TOUR_APPROVED", "Programme",
                programme.getId(), Map.of("note", Optional.ofNullable(request.note()).orElse(""))));

        // Step 7: notifications happen after commit, so a mail failure can
        // never roll back an approval that already succeeded.
        events.publishEvent(new TourApprovedEvent(programme.getId()));

        return programme;
    }

    private void spawnRequirementsOnApproval(Programme programme, LocalDate dueDate) {
        CampusTourDetails details = tourDetailsRepository.findByProgrammeId(programme.getId())
                .orElseThrow(() -> new IllegalStateException(
                        "Programme %d has no campus tour details".formatted(programme.getId())));

        Domain hospitality = domainRepository.findByCode(HOSPITALITY_LOGISTICS)
                .orElseThrow(() -> new IllegalStateException("Domain " + HOSPITALITY_LOGISTICS + " not seeded"));
        Domain vcu = domainRepository.findByCode(VCU)
                .orElseThrow(() -> new IllegalStateException("Domain " + VCU + " not seeded"));

        if (details.isLunchRequired()) {
            createIfAbsent(programme, hospitality, RequirementKind.LUNCH, dueDate);
        }
        if (tourInterestRepository.anyRequiresApproval(programme.getId())) {
            createIfAbsent(programme, hospitality, RequirementKind.VENUE_APPROVALS, dueDate);
        }
        // Volunteers (including the escort slot) are always needed for a tour.
        createIfAbsent(programme, vcu, RequirementKind.VOLUNTEERS, dueDate);
    }

    private void createIfAbsent(Programme programme, Domain domain, RequirementKind kind, LocalDate dueDate) {
        requirementRepository.findByProgrammeIdAndKind(programme.getId(), kind)
                .orElseGet(() -> requirementRepository.save(new Requirement(programme, domain, kind, dueDate)));
    }

    private Programme reject(Programme programme, DecisionRequest request, AppUser actor) {
        programme.transitionTo(ProgrammeStatus.REJECTED);
        programme.setDecidedBy(actor);
        programme.setDecidedAt(Instant.now());
        programme.setDecisionNote(request.note());

        auditLogRepository.save(AuditLog.byUser(actor.getId(), "TOUR_REJECTED", "Programme",
                programme.getId(), Map.of("note", Optional.ofNullable(request.note()).orElse(""))));
        return programme;
    }

    private Programme proposeDate(Programme programme, DecisionRequest request, AppUser actor) {
        if (request.proposedDate() == null) {
            throw new IllegalArgumentException("proposedDate is required for PROPOSE_DATE");
        }
        programme.transitionTo(ProgrammeStatus.RESCHEDULE_PROPOSED);
        programme.setProposedDate(request.proposedDate());
        programme.setDecisionNote(request.note());

        auditLogRepository.save(AuditLog.byUser(actor.getId(), "TOUR_RESCHEDULE_PROPOSED", "Programme",
                programme.getId(), Map.of("proposedDate", request.proposedDate().toString())));
        return programme;
    }

    /**
     * Called when a school or staff member revises headcount for an already
     * approved tour: flags the domains that already acted so they notice
     * the change instead of silently working off stale numbers.
     */
    @Transactional
    public void flagRequirementsForHeadcountChange(Long programmeId) {
        for (Requirement requirement : requirementRepository.findByProgrammeId(programmeId)) {
            if (requirement.getKind() == RequirementKind.LUNCH
                    || requirement.getKind() == RequirementKind.VOLUNTEERS) {
                requirement.markNeedsAttention();
            }
        }
    }
}
