package com.prayas.platform.tour;

import com.prayas.platform.auth.CurrentUser;
import com.prayas.platform.user.AppUser;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/tour-requests")
public class TourRequestController {

    private final TourDecisionService decisionService;

    public TourRequestController(TourDecisionService decisionService) {
        this.decisionService = decisionService;
    }

    // Access is enforced by AccessService.canDecide, which checks the caller
    // is a Lead, Faculty In-charge, or a Campus Tour domain head.
    @PostMapping("/{id}/decision")
    @PreAuthorize("@access.canDecide(#id)")
    public ProgrammeView decide(@PathVariable Long id,
                                 @Valid @RequestBody DecisionRequest request,
                                 @CurrentUser AppUser actor) {
        Programme programme = decisionService.decide(id, request, actor);
        return ProgrammeView.from(programme);
    }
}
