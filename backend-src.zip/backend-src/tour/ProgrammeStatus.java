package com.prayas.platform.tour;

import java.util.EnumSet;
import java.util.Set;

/**
 * Programme lifecycle. Keeping the transition rules here (rather than
 * scattered through services) means the whole state machine is covered
 * by one focused unit test.
 */
public enum ProgrammeStatus {
    SUBMITTED,
    UNDER_REVIEW,
    RESCHEDULE_PROPOSED,
    APPROVED,
    REJECTED,
    CANCELLED,
    COMPLETED;

    private static final Set<ProgrammeStatus> FINAL_STATES =
            EnumSet.of(REJECTED, CANCELLED, COMPLETED);

    public boolean isFinal() {
        return FINAL_STATES.contains(this);
    }

    public boolean canMoveTo(ProgrammeStatus next) {
        if (this.isFinal()) {
            return false;
        }
        return switch (this) {
            case SUBMITTED -> next == UNDER_REVIEW || next == CANCELLED;
            case UNDER_REVIEW -> next == APPROVED || next == REJECTED
                    || next == RESCHEDULE_PROPOSED || next == CANCELLED;
            case RESCHEDULE_PROPOSED -> next == UNDER_REVIEW || next == CANCELLED;
            case APPROVED -> next == COMPLETED || next == CANCELLED;
            default -> false;
        };
    }
}
