package com.prayas.platform.domain;

public enum DomainRole {
    HEAD,
    COORDINATOR,
    VOLUNTEER
}
