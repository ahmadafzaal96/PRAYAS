package com.prayas.platform.domain;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface DomainMembershipRepository extends JpaRepository<DomainMembership, DomainMembership.Id> {

    @Query("""
           select count(m) > 0 from DomainMembership m
           where m.user.id = :userId
             and m.domain.code = :domainCode
             and m.domainRole = :role
           """)
    boolean existsByUserAndDomainCodeAndRole(@Param("userId") Long userId,
                                              @Param("domainCode") String domainCode,
                                              @Param("role") DomainRole role);
}
