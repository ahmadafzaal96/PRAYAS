package com.prayas.platform.user;

public enum GlobalRole {
    FACULTY_INCHARGE,
    LEAD,
    MEMBER
}
