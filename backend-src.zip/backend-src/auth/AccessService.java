package com.prayas.platform.auth;

import com.prayas.platform.domain.DomainMembershipRepository;
import com.prayas.platform.domain.DomainRole;
import com.prayas.platform.user.AppUser;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

/**
 * Every authorization decision in the app goes through this class, so a
 * permission rule only has to be read (and tested) in one place, and the
 * frontend never has to be trusted to hide a button correctly.
 * Registered as bean "access" so @PreAuthorize("@access.canDecide(#id)") resolves.
 */
@Service("access")
public class AccessService {

    private final DomainMembershipRepository membershipRepository;

    public AccessService(DomainMembershipRepository membershipRepository) {
        this.membershipRepository = membershipRepository;
    }

    /** Lead, Faculty In-charge, or a Campus Tour domain HEAD may decide a tour request. */
    public boolean canDecide(Long programmeId) {
        AppUser user = currentUser();
        if (user == null) {
            return false;
        }
        if (user.isLeadOrFaculty()) {
            return true;
        }
        return hasDomainRole(user, "CAMPUS_TOUR", DomainRole.HEAD);
    }

    /** Domain coordinator/head, or Lead/Faculty, may update a requirement in that domain. */
    public boolean canUpdateRequirement(String domainCode) {
        AppUser user = currentUser();
        if (user == null) {
            return false;
        }
        if (user.isLeadOrFaculty()) {
            return true;
        }
        return hasDomainRole(user, domainCode, DomainRole.HEAD)
                || hasDomainRole(user, domainCode, DomainRole.COORDINATOR);
    }

    private boolean hasDomainRole(AppUser user, String domainCode, DomainRole role) {
        return membershipRepository.existsByUserAndDomainCodeAndRole(user.getId(), domainCode, role);
    }

    private AppUser currentUser() {
        Object principal = SecurityContextHolder.getContext().getAuthentication() == null
                ? null
                : SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return principal instanceof AppUser appUser ? appUser : null;
    }
}
