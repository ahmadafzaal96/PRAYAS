package com.prayas.platform.auth;

import com.prayas.platform.tour.PublicSubmitRateLimitFilter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.filter.CorsFilter;

/**
 * Two audiences, two trust levels:
 *  - /api/v1/public/**  no login; protected by captcha + honeypot + rate
 *    limit in the service layer instead (see PublicSubmitRateLimitFilter).
 *  - everything else    Google OAuth2 login, restricted below to accounts
 *    on the institute's email domain. A restricted-domain login still
 *    needs a matching app_user row (see CurrentUserArgumentResolver) --
 *    domain-matching only keeps random Gmail accounts out, it does not
 *    grant access by itself.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Value("${prayas.auth.allowed-email-domain}")
    private String allowedEmailDomain;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http, PublicSubmitRateLimitFilter rateLimitFilter)
            throws Exception {
        http
            .csrf(csrf -> csrf.ignoringRequestMatchers("/api/v1/public/**"))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/v1/public/**", "/actuator/health").permitAll()
                .anyRequest().authenticated())
            .oauth2Login(oauth2 -> oauth2
                .userInfoEndpoint(userInfo -> userInfo.userService(domainRestrictedUserService())))
            .addFilterBefore(rateLimitFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

    /**
     * Rejects the OAuth2 login outright if the Google account's email isn't
     * on the institute domain, before Spring Security ever creates a
     * session for it.
     */
    private DefaultOAuth2UserService domainRestrictedUserService() {
        DefaultOAuth2UserService delegate = new DefaultOAuth2UserService();
        return new DefaultOAuth2UserService() {
            @Override
            public OAuth2User loadUser(OAuth2UserRequest request) {
                OAuth2User user = delegate.loadUser(request);
                String email = user.getAttribute("email");
                if (email == null || !email.toLowerCase().endsWith("@" + allowedEmailDomain)) {
                    throw new OAuth2AuthenticationException(
                            "Only @" + allowedEmailDomain + " accounts may sign in");
                }
                return user;
            }
        };
    }

    @Bean
    public PublicSubmitRateLimitFilter publicSubmitRateLimitFilter() {
        return new PublicSubmitRateLimitFilter();
    }
}
