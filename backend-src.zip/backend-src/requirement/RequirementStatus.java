package com.prayas.platform.requirement;

public enum RequirementStatus {
    PENDING,
    IN_PROGRESS,
    DONE,
    BLOCKED,
    CANCELLED
}
