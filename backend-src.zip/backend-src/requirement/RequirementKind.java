package com.prayas.platform.requirement;

public enum RequirementKind {
    LUNCH,
    VOLUNTEERS,
    VENUE_APPROVALS
}
