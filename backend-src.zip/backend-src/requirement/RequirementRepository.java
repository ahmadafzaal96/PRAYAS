package com.prayas.platform.requirement;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface RequirementRepository extends JpaRepository<Requirement, Long> {

    Optional<Requirement> findByProgrammeIdAndKind(Long programmeId, RequirementKind kind);

    List<Requirement> findByProgrammeId(Long programmeId);

    List<Requirement> findByDomainId(Long domainId);

    List<Requirement> findByDomainIdAndStatus(Long domainId, RequirementStatus status);
}
