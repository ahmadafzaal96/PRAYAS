package com.prayas.platform.venue;

public enum VenueType {
    LEGACY_ROOM,
    LIBRARY,
    LAB,
    SPORTS,
    CLASSROOM,
    OTHER
}
