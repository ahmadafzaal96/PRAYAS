package com.prayas.platform.venue;

import jakarta.persistence.*;

@Entity
@Table(name = "venue")
public class Venue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name = "venue_type", nullable = false)
    private VenueType venueType;

    private String department;

    private Integer capacity;

    // Set manually by an admin per venue -- there is no blanket rule.
    // When true, approving a tour that includes this venue spawns a
    // VENUE_APPROVALS requirement for Hospitality & Logistics (phase 2).
    @Column(name = "requires_approval", nullable = false)
    private boolean requiresApproval = false;

    @Column(name = "public_visible", nullable = false)
    private boolean publicVisible = true;

    @Column(columnDefinition = "text")
    private String description;

    @Column(name = "is_active", nullable = false)
    private boolean active = true;

    protected Venue() {
        // JPA
    }

    public Venue(String name, VenueType venueType) {
        this.name = name;
        this.venueType = venueType;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public VenueType getVenueType() {
        return venueType;
    }

    public boolean requiresApproval() {
        return requiresApproval;
    }

    public String getDepartment() {
        return department;
    }

    public String getDescription() {
        return description;
    }

    public void setRequiresApproval(boolean requiresApproval) {
        this.requiresApproval = requiresApproval;
    }

    public boolean isPublicVisible() {
        return publicVisible;
    }

    public void setPublicVisible(boolean publicVisible) {
        this.publicVisible = publicVisible;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
