package com.prayas.platform.tour;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Proves the daily cap (set to 3 for Prayas) actually holds when several
 * leads approve different tours for the same date at the same instant --
 * the scenario the advisory lock in TourDecisionService exists for.
 * Uses a real Postgres via Testcontainers because pg_advisory_xact_lock
 * has no H2 equivalent worth trusting.
 */
@Testcontainers
@SpringBootTest
class TourDecisionServiceConcurrencyTest {

    @Container
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:15-alpine");

    @DynamicPropertySource
    static void datasourceProps(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", postgres::getJdbcUrl);
        registry.add("spring.datasource.username", postgres::getUsername);
        registry.add("spring.datasource.password", postgres::getPassword);
    }

    @Autowired
    private TourDecisionService decisionService;

    @Autowired
    private TourTestFixtures fixtures; // seeds domains, a school, and N SUBMITTED programmes for one date

    @Test
    void onlyMaxPerDayApprovalsSucceedWhenRacedConcurrently() throws InterruptedException {
        LocalDate sameDate = LocalDate.now().plusDays(30);
        int candidateCount = 6; // more requests than the cap, to force contention
        List<Long> programmeIds = fixtures.createSubmittedProgrammes(sameDate, candidateCount);

        ExecutorService pool = Executors.newFixedThreadPool(candidateCount);
        CountDownLatch startGate = new CountDownLatch(1);
        AtomicInteger approved = new AtomicInteger();
        AtomicInteger rejectedByCapacity = new AtomicInteger();

        List<Future<?>> futures = programmeIds.stream().map(id -> pool.submit(() -> {
            try {
                startGate.await();
                decisionService.decide(id,
                        new DecisionRequest(DecisionType.APPROVE, "race test", null),
                        fixtures.anyLeadUser());
                approved.incrementAndGet();
            } catch (DailyCapExceededException e) {
                rejectedByCapacity.incrementAndGet();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        })).toList();

        startGate.countDown(); // release all threads at once
        for (Future<?> f : futures) {
            try {
                f.get(10, TimeUnit.SECONDS);
            } catch (ExecutionException | TimeoutException e) {
                // surfaced via the assertions below
            }
        }
        pool.shutdown();

        assertThat(approved.get()).isEqualTo(3); // TourProperties.maxPerDay for Prayas
        assertThat(rejectedByCapacity.get()).isEqualTo(candidateCount - 3);
    }
}
