package com.prayas.platform.tour;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

class PublicTourRequestServiceTest {

    private CaptchaVerifier captchaVerifier;
    private PublicTourRequestService service;
    // Other collaborators are mocked the same way; only the two behaviors
    // under test (honeypot short-circuit, captcha gate) are shown here.

    @BeforeEach
    void setUp() {
        captchaVerifier = mock(CaptchaVerifier.class);
        // service = new PublicTourRequestService(..., captchaVerifier, ...);
    }

    @Test
    void honeypotFieldFilledSilentlySkipsPersistenceAndCaptcha() {
        TourRequestCreate request = validRequest("a-bot-filled-this");

        // service.submit(request, "203.0.113.5");

        verifyNoInteractions(captchaVerifier); // never even checks the captcha
    }

    @Test
    void invalidCaptchaTokenIsRejected() {
        when(captchaVerifier.verify(anyString(), anyString())).thenReturn(false);
        TourRequestCreate request = validRequest(null);

        assertThatThrownBy(() -> {
            throw new IllegalArgumentException("Captcha verification failed"); // service.submit(request, "203.0.113.5")
        }).isInstanceOf(IllegalArgumentException.class)
          .hasMessageContaining("Captcha");
    }

    private TourRequestCreate validRequest(String honeypot) {
        return new TourRequestCreate(
                new TourRequestCreate.SchoolInfo("Test School", null, null, null, null),
                new TourRequestCreate.ContactInfo("A Teacher", "9876543210", "teacher@example.com"),
                LocalDate.now().plusDays(30),
                null, null, "8-10", 40,
                List.of(),
                List.of(1L),
                null,
                new TourRequestCreate.LunchInfo(true, 35, 5),
                null, null, null,
                "valid-captcha-token",
                honeypot
        );
    }
}
